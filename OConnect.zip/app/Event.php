<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Event extends Model 
{
    protected $table = 'event_info';
    public $timestamps = false;
}
