<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class CorpPerRel extends Model 
{
    protected $table = 'corp_per_rel';
    public $timestamps = false;
}
