<div class="copyright">
	<div class="copyrighttop">
		
		<ul>
			<li><h4>Contact Us : XXX-XXX-XXXX </h4></li>

		</ul>
	</div>
	<div class="copyrightbottom">
		<!-- <p>© 2017 All rights reserved | Design by <a href="http://w3layouts.com/">W3layouts</a></p> -->
	</div>
	<div class="clearfix"></div>
</div>