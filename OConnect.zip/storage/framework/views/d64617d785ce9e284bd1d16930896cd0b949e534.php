<!doctype html>
<html lang="<?php echo e(app()->getLocale()); ?>">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <title>Laravel</title>
    
    <!-- Fonts -->
    <link href="<?php echo URL::asset('css/bootstrap.css'); ?>" rel="stylesheet" type="text/css" media="all" />
    <link href="<?php echo URL::asset('css/styleHome.css'); ?>" rel="stylesheet" type="text/css" media="all" />
    <script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.3/umd/popper.min.js" integrity="sha384-vFJXuSJphROIrBnz7yo7oB41mKfc8JzQZiCq4NCceLEaO4IHwicKwpJf9c9IpFgh" crossorigin="anonymous"></script>
    <script src="<?php echo URL::asset('js/bootstrap.js'); ?>"></script>
    <!-- Styles -->
    <style>
        @font-face {
            font-family: sarabun;
            src: url(<?php echo URL::asset('font/THSarabunNew.ttf'); ?>);
}
html, body {
    font-family: sarabun;
    background-color: #F4F8FB;
}
header{
    width:100%; 
    background:#fafafa; 
    height:60px; 
    line-height:60px;
    border-bottom:1px solid #dddddd;
}
footer{
    width:100%; 
    background:#fafafa; 
    height:60px; 
    line-height:60px;
    border-top:1px solid #dddddd;
}
.bg{
    background-color: #f5f5f5;
    border:1px solid #dddddd;
    border-radius:4px;
    margin: 15px;
}
.card-img-container{
    width:100%;
    position: relative;
    overflow: hidden;
}
.desc{
    padding: 15px;
}
.title{
    font-size: 30px;
    font-weight: bold;
}
.description{
    font-size: 24px;
    line-height: 1em;
    padding-bottom: 5px;
}
.location{
    font-size: 24px;
}
.date{
    font-size: 24px;
}
.time{
    font-size: 24px;
}
.ccontract{
    font-size: 24px;
}
.ffacebook{
    font-size: 24px;
}
th,td{
    text-align: center;
}
</style>
</head>
<body>
    <header>
        <div class="container">
            <h1><a class="navbar-brand"><span>O</span>Connect</a></h1>
        </div>
    </header>

    <div class="container">
        <div class="row">
            <div class="col-xs-12 col-sm-4 col-md-4">
                <div class="bg">
                    <div class="card-img-container">
                        <img src="<?php echo URL::asset('img/logo.jpg'); ?>" alt="logo" class="logo">
                    </div>
                    <div class="desc">
                        <?php $__currentLoopData = $event; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $e): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="title">
                            <?php echo e($e->event_topic); ?>

                        </div>
                        <div class="description">
                            <?php echo e($e->event_description); ?>

                        </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                </div>
            </div>
            
            <div class="col-xs-12 col-sm-8 col-md-8">
                <div class="bg">
                    <div class="desc">
                        <div class="title">
                            <center>    
                                ผู้ที่สนใจเข้าร่วม
                                <?php $__currentLoopData = $event; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $e): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <form action="/event/<?php echo e($e->event_id); ?>/search" method="post">
                                    <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    <input type="text" name="criteria" value="<?php echo e($criteria); ?>" style="width:50%">
                                    <button type="submit"><img src="<?php echo URL::asset('img/search.png'); ?>" style="width:20px;height:20px;" alt="cover"></button>
                                </form>
                            </center>
                        </div>
                        <?php if(isset($buyer[0])): ?>
                            <table class="table">
                                <thead class="thead-inverse">
                                    <tr>
                                        <th>#</th>
                                        <th>ชื่อ</th>
                                        <th>เบอร์โทร</th>
                                        <th>อีเมล์</th>
                                        <th>บริษัท</th>
                                        <th>เวลาที่ถูกจองไว้แล้ว</th>
                                        <th>จองเวลา</th>
                                    </tr>
                                </thead>
                                <tbody>
                                <?php
                                    $parameter= Crypt::encrypt($criteria)
                                ?>
                                <?php $__currentLoopData = $buyer; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $b): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td scope="row"><?php echo e($loop->iteration); ?></td>
                                        <td><?php echo e($b->person_name); ?></td>
                                        <td><?php echo e($b->person_mob); ?></td>
                                        <td><?php echo e($b->person_email); ?></td>
                                        <td><?php echo e($b->corp_name); ?></td>
                                        <?php if($b->DATE_DIFF_X != ''): ?>
                                            <td><?php echo str_replace(',', '<br>', $b->DATE_DIFF_X); ?></td>
                                        <?php else: ?>
                                            <td> ยังไม่ถูกจอง </td>
                                        <?php endif; ?>
                                        
                                        <td><a href="/event/appointment/<?php echo e($parameter); ?>/<?php echo e($b->corp_per_rel_id); ?>"><img src="<?php echo URL::asset('img/datetime.png'); ?>" style="width:20px;height:20px;" alt="cover"></a></td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                        <?php else: ?>
                            <center style="padding-top:15px;">
                                <span style="font-size:20px;">ไม่พบผู้ที่สนใจเข้าร่วม</span>
                            <center>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </div>

    </div>
    
    <footer>
        <div class="container" style="text-align:center">
            <center>
                <img src="<?php echo URL::asset('img/ttt.png'); ?>" style="width:60px;height:60px;margin-top:15px" alt="cover">
                <img src="<?php echo URL::asset('img/facebook.png'); ?>" style="width:60px;height:60px;margin-top:15px" alt="cover">
                <img src="<?php echo URL::asset('img/twitter.png'); ?>" style="width:60px;height:60px;margin-top:15px" alt="cover">
            </center>
            <center>©2017 All Rights Reserved | Design by itangx & falcon</center>
        </div>
    </footer>
</body>
</html>
