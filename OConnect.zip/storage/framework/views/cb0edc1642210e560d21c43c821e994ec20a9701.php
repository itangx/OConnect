<div class="header-w3layouts"> 
	<nav class="navbar navbar-default navbar-fixed-top">
		<div class="container">
			<div class="navbar-header page-scroll">
				<button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-ex1-collapse">
					<span class="sr-only">FoodChef</span>
					<span class="icon-bar"></span>
					<span class="icon-bar"></span>
					<span class="icon-bar"></span>
				</button>
				<h1><a class="navbar-brand" href="#"><span>O</span>Connect</a></h1>
			</div> 
			<div class="collapse navbar-collapse navbar-ex1-collapse">
				<ul class="nav navbar-nav navbar-right">
					<li class="hidden"><a class="page-scroll scroll" href="#page-top"></a>	</li>
					<li><a class="page-scroll scroll" href="#home">Home</a></li>
					<li><a class="page-scroll scroll" href="#home">Home1</a></li>						
				</ul>
			</div>
		</div>
	</nav>  
</div>	
